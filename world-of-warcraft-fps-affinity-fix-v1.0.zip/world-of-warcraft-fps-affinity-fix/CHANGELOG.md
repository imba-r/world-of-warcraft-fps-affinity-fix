# Changelog

## v1.0
- Initial release
- CPU affinity control (disables cores 0–3, enables 4–15 by default)
- RealTime priority with High fallback
- Restart detection
- Timestamped logging
- Tested with World of Warcraft 12.0.1
